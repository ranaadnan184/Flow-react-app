import React from 'react'
import Dumydata from './Dumydata'
import './style.css'

export default function Dumycard() {
  return (
    <div>
      <div className='dummy-card-main'>
       {
        Dumydata.map((item)=>{
               return(
                <div className='innerdumy-card'>
               <img src={item.dpic}/>
                <p>{item.title}</p>
                </div>
               )
        })
       }
      </div>
    </div>
  )
}
