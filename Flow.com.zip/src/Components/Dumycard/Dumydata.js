import img from '../../images/sppic1.png'
import img1 from '../../images/sppic2.jpg'
import img2 from '../../images/sppic3.jpeg'
import img3 from '../../images/sppic4.jpeg'
import img4 from '../../images/sppic5.png'
import img5 from '../../images/sppic6.png'
import img6 from '../../images/sppic7.png'
import img7 from '../../images/sppic8.png'
import img8 from '../../images/sppic9.png'
import img9 from '../../images/sppic10.png'
import img10 from '../../images/sppic11.png'
import img11 from '../../images/sppic11.png'



const Dumydata=[
    {
   dpic:img,
   title:"Alchemy"
},    {
    dpic:img1,
    title:"Nyxl"
 },    {
    dpic:img2,
    title:"Blocto"
 },    {
    dpic:img3,
    title:"Bloctobay"
 },    {
    dpic:img4,
    title:"Cryptoys"
 },    {
    dpic:img5,
    title:"Dimension X"
 },    {
    dpic:img6,
    title:"ADr.Seuss"
 },    {
    dpic:img7,
    title:"Eternal"
 },    {
    dpic:img8,
    title:"Fancraze"
 },    {
    dpic:img9,
    title:"Alchemy"
 },    {
    dpic:img10,
    title:"Flovatar"
 },    {
    dpic:img11,
    title:"NFT Genius"
 },
 {
    dpic:img10,
    title:"Flovatar"
 },    {
    dpic:img11,
    title:"NFT Genius"
 },
 {
    dpic:img5,
    title:"Genies"
 },    {
     dpic:img4,
     title:"Giglabs"
  },    {
     dpic:img3,
     title:"The Fabricant"
  },    {
     dpic:img2,
     title:"The Fabricant"
  },    {
     dpic:img1,
     title:"Instagram"
  },    {
     dpic:img6,
     title:"Joyride"
  },    {
     dpic:img7,
     title:"Matrix World"
  },    {
     dpic:img8,
     title:"OneFootball"
  },    {
     dpic:img9,
     title:"OneFootball"
  },    {
     dpic:img10,
     title:"Alchemy"
  }, 
]



export default Dumydata;