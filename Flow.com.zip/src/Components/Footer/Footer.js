import React from 'react'
import './style.css';

export default function Footer() {
  return (
    <div className='footer-main'>
        <div className='inner-footer'>
      <a href='#'>JOIN FLOW ON</a>
       <a href='#'>TWITTER</a>
       <a href='#'>DISCORD</a>
       <a href='#'>FLOW.COM</a>
       </div>
    </div>
  )
}
