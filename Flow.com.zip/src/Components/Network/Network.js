import React from 'react'
import './style.css';

export default function Network() {
  return (
    <>
    <div className='main-network'>
      <div className='network-left'>
          <div className='logo-left'>
           <h1>the most friendly carbon WEB3 network</h1>
          </div>
          <p> Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla, ut nihil explicabo sed vitae eum quasi omnis. Sint cumque quae ipsum error alias eos dolores modi ad, doloremque rerum? Blanditiis!</p>
        
         <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi deleniti quod architecto nesciunt maiores placeat delectus ut similique expedita sed totam, illo dolores blanditiis facere, consequatur nam cupiditate, velit earum.</p>
         <button>Learn more</button>
       </div>
       <div className='network-right'>
       
          <div className='logo-right'>
           <h1>$725 million Ecosystem fund</h1>
          </div>
          <p> Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla, ut nihil explicabo sed vitae eum quasi omnis. Sint cumque quae ipsum error alias eos dolores modi ad, doloremque rerum? Blanditiis!</p>
        
         <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi deleniti quod architecto nesciunt maiores placeat delectus ut similique expedita sed totam, illo dolores blanditiis facere, consequatur nam cupiditate, velit earum.</p>
         <button>Learn more</button>
      </div>
    </div>
    <hr color='black'/>
    </>
  )
}
