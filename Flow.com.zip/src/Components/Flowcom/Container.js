import React from 'react'
import './Style.css';

export default function DeveloperBuilding() {
  return (
    <div className='developer-1'>
    <hr color='black'/>
    <div className='developer-building'>
      <div className='developer-building-inner'>
         <div className='wallet-transaction'>
            <div>
                <p>developer Building</p>
                <h1>8000+</h1>
            <hr id='hr1'  color='white'/>

            </div>
            <hr id='hr2'  color='white'/>
            <div>
                <p>Total wallet account account</p>
                <h1>14M</h1>
            <hr id='hr1'  color='white'/>

            </div>
            <hr id='hr2' color='white'/>

            <div>
                <p>Active Project</p>
                <h1>10000+</h1>
            <hr id='hr1'  color='white'/>

            </div>
            <hr id='hr2'  color='white'/>

            <div>
                <p>Network Node</p>
                <h1>8000+</h1>
                <hr id='hr1'  color='white'/>

            </div>
            <hr id='hr2'  color='white'/>

            <div>
                <p>Monthaly Transaction Wallet</p>
                <h1>6000+</h1>
            <hr id='hr1'  color='white'/>

            </div>

         </div>
         <hr id='hr3' color='white'/>
         <div className='blockchain-partner'>
           <div className='chain-left'> <span>
                <i>Flow is the blockchain partner for your favorite brands:</i>
            </span></div>
            <div className='chain-right'><span>
                <p>Total wallet account account</p>
            </span>
            <span>
                <p>Active Project</p>
            </span>
            <span>
                <p>Network Node</p>
            </span>
            <span>
                <p>Monthaly Transaction Wallet</p>
            </span>
            </div>
         </div>
      </div>
    </div>
    <hr color='black'/>

    </div>
  )
}
