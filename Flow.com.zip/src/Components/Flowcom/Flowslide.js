import React, { Component } from "react";
import Slider from "react-slick";
import img from '../../images/nft.jfif'
import binance from '../../images/opi.jfif'
import OIP from '../../images/OIP.jfif'
import OIP1 from '../../images/OIP1.jfif'
import OIP2 from '../../images/oip2.jfif'
import logoflow from '../../images/logoflow.png'
import './Reactslide.css';


export default class PauseOnHover extends Component {
  render() {
    var settings = {
      dots: true,
      infinite: true,
      slidesToShow: 3,
      slidesToScroll: 1,
      autoplay: true,
      autoplaySpeed: 2000,
      pauseOnHover: false
    };
    return (
      <div className="react-slice">
        <h2>PURCHASE FLOW</h2>
        <Slider {...settings}>
          <div className="slideimg1">
            <h3>
                <img src={img}/>
            </h3>
          </div>
          <div className="slideimg2">
          <img src={binance}/>

          </div>
          <div className="slideimg3">
            <img src={OIP}/>

          </div>
          <div className="slideimg4">
          <img src={OIP1}/>


          </div>
          <div className="slideimg5">
          <img src={OIP2}/>


          </div>
          <div className="slideimg6">
          <img src={logoflow}/>


          </div>
        </Slider>
      </div>
    );
  }
}