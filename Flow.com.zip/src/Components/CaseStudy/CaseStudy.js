import React from 'react'
import './style.css';

export default function CaseStudy() {
  return (
    <div className='Case-study-main'>
        <h2>Case Studies</h2>
      <div className='Case-study-main-1'>
  <div className='case-1'>
   <h1>Emerland City DAO</h1>
   <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum ex ad delectus eum doloremque illum porem.</p>
  </div>
  <div className='case-1'>
  <h1>Emerland City DAO</h1>
   <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum ex ad delectus eum doloremque illum porem.</p>
  </div>
  <div className='case-1'>
  <h1>Emerland City DAO</h1>
   <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum ex ad delectus eum doloremque illum porem.</p>
  </div>
  <div className='case-1'>
  <h1>Emerland City DAO</h1>
   <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum ex ad delectus eum doloremque illum porem.</p>
  </div>
      </div>
      <div className='Case-study-main-3'>
    
      <div className='Case-study-inner'>
    <div className='inner-1'>
   <h1>Emerland City DAO</h1>
   <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum ex ad delectus eum doloremque illum porem.</p>
  </div>
  <div className='inner-2'>
  <h1>Emerland City DAO</h1>
   <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum ex ad delectus eum doloremque illum porem.</p>
  </div>
  <div className='inner-3'>
  <h1>Emerland City DAO</h1>
   <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum ex ad delectus eum doloremque illum porem.</p>
  </div>
 
      </div>

      <div className='Case-study-inner-1'>
      <div className='inner-info'>
        <h1>TOPSHOT</h1>
      </div>
      <div className='inner-info'>
      <p>Owners</p>
      <h1>75000+</h1>
      </div>
      <div className='inner-info'>
      <p>Primary</p>
      <h1>$200M+</h1>
      </div>
      <div className='inner-info'>
      <p>Secondary</p>
      <h1>$1B+</h1>
      </div>
      </div>

      
      
      <div className='Case-study-inner-1'>
      <div className='inner-info'>
        <h1>AllDay</h1>
      </div>
      <div className='inner-info'>
      <p>Owners</p>
      <h1>78000+</h1>
      </div>
      <div className='inner-info'>
      <p>Primary</p>
      <h1>$250M+</h1>
      </div>
      <div className='inner-info'>
      <p>Secondary</p>
      <h1>$1.5B+</h1>
      </div>
      </div>
      <div className='parent-study-1'>
      <div className='Case-study-inner-4'>
      <div className='baller-1'>
        <h1>UFC STRIKE</h1>
      </div>
      <div className='baller-1'>
      <p>Owners</p>
      <h3>78000+</h3>
      </div>
      <div className='baller-1'>
      <p>Primary</p>
      <h3>$250M+</h3>
      </div>
     
      </div>
      <div className='Case-study-inner-4'>
      <div className='baller-1'>
        <h1>BALLERZ</h1>
      </div>
      <div className='baller-1'>
      <p>Owners</p>
      <h3>78000+</h3>
      </div>
      <div className='baller-1'>
      <p>Primary</p>
      <h3>$250M+</h3>
      </div>
     
      </div>
      </div>
      </div>
    </div>
  )
}
