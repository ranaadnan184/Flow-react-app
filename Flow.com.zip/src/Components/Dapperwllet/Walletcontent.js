import React from 'react'
import './style.css';
import { BsArrowRight } from 'react-icons/bs';
// import img from '../../images/pic1.jpg'

export default function Walletcontent() {
  return (
    <>
      <div className='back-img'>
       {/* <img src={img}/> */}
     

       <div className='main-wallet'>
         <div className='wallet-1'>
        <div className='col-no1'><i><BsArrowRight size={50}/></i><h4>Dapper Wallet Now Sports $ Coins</h4></div>
        <div className='col-no2'><i><BsArrowRight size={50}/></i><h4>Builed a front-end and run your transaction on Flow blockchain within minuts </h4></div>
        <div className='col-no3'><i><BsArrowRight size={50}/></i><h4>Becom a Flow Ambassdor</h4></div>
         </div>
         <div className='wallet-2'>
        <h1>Build A Powerful Secure And Scalable Web# Apps</h1>
         <h4 id='icon-arrow'>Start Build Now<i ><BsArrowRight size={30} /></i></h4>
         </div>
         </div>
         </div>
         </>
  )
}
