import React from 'react'
import './style.css';
import { BsArrowRight } from 'react-icons/bs';

import img from '../../images/nft.jfif'
import binance from '../../images/opi.jfif'
import OIP from '../../images/OIP.jfif'
import OIP1 from '../../images/OIP1.jfif'
import OIP2 from '../../images/oip2.jfif'
import logoflow from '../../images/logoflow.png'




export default function Community() {
  return (
    <div className='main-content'>
      <h1 id='community-heading-first'>Home to the world’s most trusted communities.</h1>

      <div className='community'>

       <div className='community-left'>
         <p>Flow is a powerful tool for developers to create empowering experiences for users. Every aspect of the platform was designed from the ground up to support exceptional experiences at mainstream scale.
<br></br>
<br></br>
Originally conceived by the team behind CryptoKitties, Flow today is a decentralized network supported and built on by a growing community of  brands and Web3 builders.</p>
       </div>
       <div className='community-right'>
        <div className='com-no2'><h4>Learn More At Fllowvers </h4><i><BsArrowRight size={50}/></i></div>
        <div className='com-no3'><h4>join us on discover</h4><i><BsArrowRight size={50}/></i></div>
      </div>
      </div>
      {/* <div className='main-btn-card'>

  <div className='card-row-first'>
  <div className='cardbtn-parent-1'>
  <div className='card-btn-1'>
     <img src={img}/>
     <span>Giagia</span>
  </div>
  <div className='card-btn-1'>
     <img src={binance}/>
     <span>Binance</span>
  </div>
  
  <div className='card-btn-1'>
     <img src={OIP1}/>
     <span>Crypto</span>
  </div>
  </div>
  <div className='cardbtn-parent-1'>
  <div className='card-btn-1'>
     <img src={binance}/>
     <span>Binance</span>
  </div>
  <div className='card-btn-1'>
     <img src={OIP}/>
     <span>NFT</span>
  </div>
  <div className='card-btn-1'>
     <img src={OIP1}/>
     <span>Crypto</span>
  </div>
  
  </div>

  
  </div>

  

      </div> */}
    </div>
  )
}
