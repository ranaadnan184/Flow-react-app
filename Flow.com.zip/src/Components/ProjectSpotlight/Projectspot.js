import React from 'react'
import './style.css';
import { BsArrowRight } from 'react-icons/bs';
import img from '../../images/pic2.png'
import Music from '../../images/pic3.png'
import sport from '../../images/pic1.png'
export default function Projectspot() {
  return (
    <div>
        {/* <div className='Project-spot-1'>
       <div className='project-fashion'>
        <div id='img1'><img src={img}/></div>
        <button>Fashion</button>
        <h1>Genies</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusamus, sapiente ad, magni dicta </p>

        <a href='#'>Learn more</a>
       </div>
       <div className='project-fashion'>
        <div id='img1'><img src={Music}/></div>
        <button>Music</button>
        <h1>RDRC SHP</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusamus, sapiente ad, magni dicta </p>

        <a href='#'>Learn more</a>
       </div>
       <div className='project-fashion'>
        <div id='img1'><img src={sport}/></div>
        <button>Fashion</button>
        <h1>BALLERZ</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusamus, sapiente ad, magni dicta </p>
        <a href='#'>Learn more</a>
       </div>
      
        </div> */}

     <div className='developer-experience-main'>
<div className='experience-left'>
<h1>Developer-First experience</h1>
  <p>
Battle-tested in production and ready to help you build the kinds of applications that people want to use.</p>

<button>Start Building <i><BsArrowRight id='arrow'  color="black"/></i></button>
</div>
<div className='experience-right'>
    <div className='Cadence'>
    <h1>Cadence</h1>
    <p>The new easy-to-learn programming language designed for dapps and digital assets</p>
    <h2>Upgradable Smart Contracts</h2>
    <span>Securely and transparently patch bugs and upgrade pre-specified parts of a smart contract</span>
    </div>
    <div className='library'>
    <h1>Flow Client Library</h1>
    <p>One snippet of code that lets you support any wallet on Flow self-custody or fiat payments</p>
    <h2>Fast and Deterministic Finality</h2>
    <span>Flow is built to be fast and responsive  achieving global finality within seconds</span>
    </div>
</div>
    </div> 


    
    {/* Consumer friendly */}


    <div className='Consumer-friendly-main'>
<div className='Consumer-left'>
<h1>Consumer Friendly Onboarding</h1>
  <p>
  Flow standardizes usability improvements for crypto traders and sports fans alike, letting you focus on what matters.</p>

<button>Read more in our Primer <i><BsArrowRight id='arrow'  color="white"/></i></button>
</div>
<div className='Consumer-right'>
    <div className='Consumer-Cadence'>
    <h1>Mainstream-Ready Experience</h1>
    <p>Flow supports multiple payment onramps and ecosystems optimized for consumer applications</p>
    <h2>Human-Readable Security</h2>
    <span>Fundamental requirement to protect mainstream users against malicious apps and build trust in the system</span>
    </div>
    <div className='Consumer-library'>
    <h1>Smart User Accounts</h1>
    <p>Flow accounts make it easy for dapps or wallets to pay transaction fees and recover lost keys for users</p>
    <h2>Incentives for Early Adopters</h2>
    <span>A significant allocation of FLOW tokens is reserved for early user- and developer growth</span>
    </div>
</div>
    </div>


    <hr color='black'/>
    </div>
  )
}
