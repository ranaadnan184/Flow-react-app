import React from 'react'
import './style.css';
import img from '../../images/logoflow.png'
import { Link } from 'react-router-dom';

export default function Headerflow() {
  return (
    <>
    <div className='header'>
     <h4>Permissionless node operation are availabale</h4>
    </div>
    <div className='flow-nav-main'>
    <div className='flow-nav'>
            <img src={img} />
            <a href='#'>Flow</a>
            <a href='#'>About</a>
            <a href='#'>Community</a>
            <a href='#'>Partners</a>
            <Link to='/Developer'>Developers</Link>
            <Link to='/Blogheader'>Blog</Link>
            <button id='flow-nav-btn1' type='text'>Start Building</button>
            <button id='flow-nav-btn2' type='text'>Contact</button>
    </div>
    </div>
    </>
  )
}
