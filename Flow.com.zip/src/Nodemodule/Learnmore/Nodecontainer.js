import React from 'react'
import Benefits from '../Benefitsofnode/Benefits'
import Participaint from '../Participaint/Participaint'
import Privacypart from '../Privacypart/privacypart'
import Partdata from '../Participaint/Partdata'
import { GrInsecure } from "react-icons/gr";
import Nodearchitrch from '../Nodearchitechture/Nodearchitrch'

export default function Nodecontainer() {
  return (
    <div>

          <Participaint/>
          <Privacypart/>
          <Nodearchitrch/>
          <Benefits/>
        
    </div>
  )
}
