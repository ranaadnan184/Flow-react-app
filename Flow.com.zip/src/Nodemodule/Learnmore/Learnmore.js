import React from 'react'
import './style.css';
import {AiOutlineArrowRight } from 'react-icons/ai';
export default function Learnmore(props) {
    let {title} = props
  return (
    <div className='main-learn'>
 
     <div className='Learn-more'>
     <a href=''>{title} </a>
     <i><AiOutlineArrowRight/></i>
     </div>
    </div>
  )
}
