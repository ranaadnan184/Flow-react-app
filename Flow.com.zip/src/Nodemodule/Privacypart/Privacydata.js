import { SiGnuprivacyguard } from "react-icons/si";


const Privacydata=[{
    
        ptitle:"PRIVACY & SECURITY",
        pname:" Be in full control of what information is shared with other nodes.",
        pimg:<SiGnuprivacyguard/>},
             {ptitle:"DECENTRALIZATION",
             pname:" Increase the resilience of the network.",
             pimg:<SiGnuprivacyguard/>},
             {ptitle:"PARTICIPATION",
             pname:" Be an integral part of a global, composable movement..",pimg:<SiGnuprivacyguard/>}
]

export default Privacydata;