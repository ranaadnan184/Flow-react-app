import React from 'react'
// import Benefits from '../Benefitsofnode/Benefits';
import Learnmore from '../Learnmore/Learnmore';
import Privacydata from './Privacydata'
import './style.css';

export default function Privacypart() {
    // let {pname,ptitle,pimg} = props
  return (

    <div>
    <div className='parivacy-parent-cart'>
     
    {
      Privacydata.map((i)=>{
         return(
         <div className='parivacy-inner-cart'>
           <span>{i.pimg}</span>
           <h3>{i.ptitle}</h3>
            <p>{i.pname}</p>
            </div>
       )
       }
     )
    }
   </div>
   <div className="parent-rum-node">
   <div className='inner-rum-node'>
    <h1>
    Who Should Run a Node?
    </h1>

<p>Everyone! Anyone can run a node, on everyday hardware. You don’t even need to stake any FLOW. Run a node and contribute to the security and decentralization of the network.</p>
 <h1>
 Getting Started Running a Flow Node
 </h1>
 <p>For most use-cases, the Observer node is the easiest, most versatile node type to deploy. It provides a locally accessible, continuously updated and verified copy of the block data and does not require any staking. It can be easily run on any consumer-grade hardware with sufficient disk space.</p>
    <a>Explained Info</a>
   </div>
   </div>
        
  <div><Learnmore title="Run An Observer Node"/></div>
   </div>
  )
}
