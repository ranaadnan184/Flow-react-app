import React from 'react'
// import Learnmore from '../Learnmore/Learnmore'
import Benefitsdata from './Benifitsdata'
import './style.css';
import '../Participaint/style.css';
import Learnmore from '../Learnmore/Learnmore';
import Footer from '../../Components/Footer/Footer';

export default function Benefits() {
  return (
    <div>
<div className='head-benifits'><h1>Benefits of Flow’s Multi-Node Architecture</h1></div>
<div className='benifit-parent-card'>


{
       Benefitsdata.map((i)=>{
            return(
              <div className='benifit-inner-cart'>
               <span>{i.Bpic}</span>
                <h3>{i.Bname}</h3>
                <p>{i.Bdes}</p>
             </div>
        )
        }
      )
     }


</div>
     <Learnmore title="Learn More Aboute Flow's Multi Node Architechture"/>

      <div className='running-node'>
       <div className='running-text'>
       <span>
       <h1>Running a Staked Node</h1>
       <p>If you are interested in running a staked Flow node, you have several options depending on the Node type. Each staked node type requires a minimum stake.</p>
       </span>
       </div>

       <Learnmore title="Learn More About Roles"/>
       <Learnmore title="Apply to Run a Stack Node"/>
      </div> 
      <div>
      <div className='Delegation-main'>
      <div className='Delegation-inner'>
      <h1>Delegation</h1>
      <p>You don’t need to run a node to stake your FLOW. Any account in the network may also participate in staking by delegating their tokens to a node operator. Every node operator in the network is eligible to receive delegations, there is no opting out.</p>
      </div>
      </div>
      <Learnmore title="Learn More About Stacking And Deleting Your Flow"/>
       </div>
       <Footer/>
    </div>
  )
}
