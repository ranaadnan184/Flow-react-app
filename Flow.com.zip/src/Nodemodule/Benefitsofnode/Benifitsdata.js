import { AiOutlineNodeCollapse, AiOutlineSisternode } from "react-icons/ai";
import { BiNetworkChart } from "react-icons/bi";
import { BsClockHistory } from "react-icons/bs";
import { MdOutlinePrivacyTip, MdPrivacyTip } from "react-icons/md";



const Benefitsdata=[
    {
        Bpic:<AiOutlineNodeCollapse/>,
       Bname:"Scales to millions by default",
        Bdes:" by providing a highly performant base layer.",
       
    },
    {
        Bpic:<AiOutlineSisternode/>,
        Bname:"Makes network participation more accessible",
         Bdes:" by lowering requirements for certain node types ,  they can even be run on consumer-grade laptops.",
        
     },
    {
        Bpic:<BiNetworkChart />,
       Bname:"Increases decentralization",
        Bdes:" by lowering the barrier of running a node, which increases the likelihood of more nodes participating.",
       
    },
    {
        Bpic:<BsClockHistory/>,
       Bname:"Abstracts complexity into the protocol to preserve ease of development,",
        Bdes:" letting developers ship applications faster without needing to worry about infrastructure requirements.",
       
    },
    {
        Bpic:<MdPrivacyTip/>,
        Bname:"Ensures great end-user experience",
         Bdes:" by avoiding Layer 2 solutions, freeing users from needing to consider technical implication and keeping onboarding simple.",
        
     },
    {
        Bpic:<MdOutlinePrivacyTip />,
       Bname:"Preserves security at scale,",
        Bdes:" since no transaction has to rely on potentially corrupt off-chain computations and all interactions between entities can happen in one atomic, consistent, isolated, and durable (ACID) transaction.",
       
    },
  

];

export default Benefitsdata;
