import React from 'react'
// import Learnmore from '../Learnmore/Learnmore'
import './style.css';
import Partdata from './Partdata'
import { BsArrowDownShort } from 'react-icons/bs';
export default function Participaint() {
  return (
    <div className='participaint-11-1'>

    <div className='participaint-bg-image'>
 <div className='text-participaint'><h2>
  PARTICIPATE, VERIFY, DECENTRALIZE.
  </h2>
  <p>
  Anyone can run a node and participate in Flow’s unique multi-node architecture.
  </p>
  </div>

    </div>



    <div className='participaint-parent-cart'>
     
     {
      Partdata.map((i)=>{
          return(
          <div className='participaint-inner-cart'>
            <span>{i.pic}</span>
            <h3>{i.name}</h3>
             <p>{i.des}</p>
              <a>{i.btn}<BsArrowDownShort/></a>
             </div>
        )
        }
      )
     }
    </div>

    <div className='use-node'>
     <div className='inner-use'>

    
     <h1>Why Run a Node?</h1>
     <h5>Don’t just use the network, be the network.</h5>

     <p>A node is a piece of software that is connected to the blockchain. By running your own node, you have direct access to the evolving state of the network, without having to rely on third parties. This increases privacy and security, reduces reliance on external servers, and helps balance load distribution. By running a node, you also directly contribute to the security and decentralization of the whole network.</p>
     </div>
    </div>












    {/* <Learnmore title='rana adnan ' /> */}
    

    </div>

  )
}
