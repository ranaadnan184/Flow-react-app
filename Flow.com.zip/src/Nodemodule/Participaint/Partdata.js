import { AiOutlineNodeCollapse, AiOutlineSisternode } from "react-icons/ai";
import { SiNodemon } from "react-icons/si";



const Partdata=[
    {
        pic:<AiOutlineNodeCollapse/>,
       name:"PARTICIPAINT BY",
        des:"RUNNING AN OBSERVER NODE TODAY",
        btn:"Learn more"
       
    },
    {
        pic:<AiOutlineSisternode/>,
        name:"PARTICIPAINT BY",
         des:"RUNNING AN OBSERVER NODE TODAY",
         btn:"Learn more"
        
     },
    {
        pic:<SiNodemon />,
       name:"PARTICIPAINT BY",
        des:"RUNNING AN OBSERVER NODE TODAY",
        btn:"Learn more"
       
    },
  

];

export default Partdata
