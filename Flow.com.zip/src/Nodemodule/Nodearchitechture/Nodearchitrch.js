import React from 'react'
import './style.css';
import img from '../../images/gifimage.gif'
export default function Nodearchitrch() {
  return (
    <div className='parent-architech'>
    <div className='parent-architech-1'>

     <div className='inner-architech'>
<h1>Flow’s Unique Multi-Node Architecture</h1>
<div id='text-11-1-1'>
<p>Scalability is the make-or-break moment for the blockchain industry as a whole — only if networks can scale to millions by default, will millions come. The vast majority of projects rely on two approaches: sharding (Layer 1) and rollups (Layer 2). These techniques might tackle the immediate technical needs, but they introduce greater risks, minimize the benefits of decentralization and add complexity for developers and end-users in the long term.
</p>
<p>Flow’s approach is different: rather than each node having to do all the work, Flow’s nodes are specialized along the transaction pipeline. Collection nodes batch the work, consensus nodes secure the work, execution nodes do the work, verification nodes check the work. Access nodes are the interface through which builders can access the network. </p>
</div>
</div>

    </div>
    <div className='gif-image'>
        <img src={img}/>
    </div>
    <div className='secom-text-22'>
    <div className='secom-text-11'>
<p>By introducing this paradigm of pipelining, Flow’s solution is more scalable, more decentralized and more secure than existing scaling solutions, without increasing complexity for developers or needing to rely on off-chain workarounds. </p>
    </div>
    </div>
    </div>
  )
}
