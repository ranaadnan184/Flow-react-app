import React from 'react'
import FlowSystem from './FlowSystem'
import Partner from './Partner/Partner'
import SportCart from './Sportsprogram/SportCart'


export default function EcofundContainer() {
  return (
    <div>

        <FlowSystem/>
        <Partner/>
        <SportCart/>
    </div>
  )
}
