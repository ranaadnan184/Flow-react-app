import React from 'react'
import './style.css';
import img1 from '../images/ecofund.png';

export default function FlowSystem() {
  return (
    <div>
        <div className='eco-bg-image'>
         <img src={img1}/>
          </div>
        <div className='eco-parent-fund'>
         
         <h5>The largest joint commitment made towards any blockchain ecosystem</h5>
         <div className='eco-inner-fund'>
         <h3>$725 MILLION+</h3>
         <p>Our $725 Million Flow Ecosystem Fund is designed to hypercharge innovation and growth across the Flow community.</p>
        </div>
       <div className='text-partner'>
       <p>The Flow Ecosystem Fund’s global investor group includes industry-leading firms that have backed several of the most successful Web3 companies</p>
        <p>With a focus on enabling more distributed and equitable Web3 opportunities, the Ecosystem Fund will support existing and future developers in building applications on the Flow blockchain through investments, FLOW token grants and in-kind support. Available to developers around the globe, the Fund will focus on support for gaming, infrastructure, decentralized finance, content and creators.</p>
       </div>
        </div>
       </div>
  )
}

