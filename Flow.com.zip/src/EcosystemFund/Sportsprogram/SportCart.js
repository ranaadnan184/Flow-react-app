import React from 'react'
import SportData from "./SportData";
import './style.css';

export default function SportCart() {
  return (
    <div>
        <h2 id='sport-heading'>ECOSYSTEM SUPPORT PROGRAMS</h2>
    
    

        <div className='sport-card'>
           {SportData.map((item) => {
      

            return (
                  <>
                  <div className='sport-left'>
                  <img src={item.pic} />
                  </div>
                  <div className='sport-right'>
                  <h5>{item.title}</h5>
                  <p>{item.des}</p>
                  <button>{item.btn}</button>
                  </div>
                  </> 
             
        );

 

              })}
        
         </div>

   
    </div>
  )
}
