import img1 from '../../images/sport1.png'
import img2 from '../../images/sport2.jpg'
import img3 from '../../images/sport3.png'
import img4 from '../../images/sport4.png'


const SportData=[
    {
        pic:img1,
        title:"$10M Dapper Studio Ecosystem Fund",
        des:"The $10M Dapper Studio Ecosystem Program’s goal is to catalyze growth, support new builders in the industry, and create never-before-seen/felt/heard experiences for Web3 consumers focused around gaming and social play, creating new ways for our sports NFT holders (NBA Top Shot, NFL ALL DAY, UFC Strike) to have and engage with their NFT's.",
        btn:"apply for studio fun"
    },
    {
        pic:img2,
        title:"Developer Grants",
        des:"Flow's success is dependent on an active and thriving community of builders that help accelerate and enhance the process of building and consuming applications on Flow. We ensure builders can sustain their commitment through FLOW token grants for the following contributions: opensource maintenance, developer services, product bounties, and educational material. ",
        btn:"apply for a Grant"
    },
    {
        pic:img3,
        title:"Ecosystem Investments from Dapper Labs",
        des:"Dapper Labs invests in the best teams in the Flow ecosystem and the broader web3 space. Since kicking off our investment initiatives last March, we’ve invested in 120+ companies. Investors we've co-invested alongside include tier 1 VCs such as: A16Z, Tiger Global, Coatue, Bond, NEA, Animoca Brands, CoinFund among many others",
        btn:"apply for Ecosystem Investment"
    },
    {
        pic:img4,
        title:"Fundraising Support",
        des:"Companies in the Flow ecosystem have raised $3.5B+ from the world's best investors (excluding the $600M raised by Dapper Labs). We support projects in the ecosystem with fundraising support to achieve this. Support includes: outreach to 500+ VCs in our network, materials workshopping, fundraising process management, general fundraising strategy.",
        btn:"apply for studio fun"
       
    },

];


export default SportData
