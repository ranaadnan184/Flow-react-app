import React from 'react'
import { Form } from 'react-router-dom'
import './style.css'

export default function Contact() {
  return (
    <div className='contact-parent'>

    <div className='contact-inner'>
         <div>
         <div className='text-heading'>
         <h1>We'll get in contact with you soon</h1>
         <p>
         Your inquiry is important to us! If you could fill out the form below with as much detail as possible we'll be able to get your request to the right team to help you.
         </p>
         </div>
         <div className='user-name'>
         
         <p><lable>Full name <i>*</i></lable></p>
         <input type="text" required/>
         </div>
         </div>
         <div className='email-parent'>
         <div className='email-inner'>
         <p><lable>E-mail <i>*</i></lable></p>
         <input type="email" required/>
         </div>
         <div className='check-box-parent'>
            <p><lable>What platform or product are you inquiring about?
          </lable></p>
          <div className='check-box-inner'>
          <input  type="checkbox" value="" />
          <label className="">
          Flow
        </label>
        </div>
        <div className='check-box-inner'>
          <input class="" type="checkbox" value="" />
           <label className="form-check-label">
            Dapper Labs
          </label>
          </div>
          <div className='check-box-inner'>
          <input class="" type="checkbox" value="" />
           <label className="form-check-label">
            Dapper Wallet
          </label>
          </div>
          <div className='check-box-inner'>
          <input class="" type="checkbox" value="" />
           <label className="form-check-label">
           Other
          </label>
          </div>

         </div>
         
         </div>
         <div className='radio-btn'>
         <p><lable>Are you reaching out to learn how to start building on Flow? <i>*</i></lable></p>
        
       
          <div>
        <input type="radio" value="Yes" name="gender" /> Yes <br></br>
        <input type="radio" value="No" name="gender" /> NO
      </div>
          </div>
          <div className='user-name'>
         
         <p><lable>What are you reaching out about?</lable></p>
         <input type="text" required/>
         </div>
          <div className='radio-btn'>
         <p><lable>Are you reaching out to learn how to use Dapper wallet for your platform?  <i>*</i></lable></p>
        
       
          <div>
        <input type="radio" value="Yes" name="gender" /> Yes <br></br>
        <input type="radio" value="No" name="gender" /> NO
      </div>
          </div>
          <div className='radio-btn'>
         <p><lable>Do you currently have a platform that is live on Flow? <i>*</i></lable></p>
        
       
          <div>
        <input type="radio" value="Yes" name="gender" /> Yes <br></br>
        <input type="radio" value="No" name="gender" /> NO
      </div>
          </div>
          <div className='select-devlp'>
          <label for="cars">What is your role?<i>*</i></label><br></br>

<select  placeholder='Please Select' name="" id="Select-devlp">
  <option value="Founder">Founder</option>
  <option value="Developer">Developer</option>
  <option value="Marketer">Marketer</option>
  <option value="Press">Press</option>
  <option value="Other">Other</option>
</select>
          </div>



          <div className='user-name'>
         
         <lable>Description of your inquiry <i>*</i></lable><br></br>
         <textarea type="text" required/>
         </div>
         <div className='user-name'>
         
         <lable>Project summary (if applicable)</lable><br></br>
         <textarea type="text" required/>
         </div>
         <div className='btn-submit'>
         <buttonn id="btn-submit" type='submit'> Submit</buttonn>
         </div>
    </div>
   

    </div>
  )
}
