import React from 'react'
import './style.css';

import CaseStudy from '../Components/CaseStudy/CaseStudy'
import Community from '../Components/Community/Community'
import Walletcontent from '../Components/Dapperwllet/Walletcontent'
import DeveloperBuilding from '../Components/Flowcom/Container'
// import PauseOnHover from '../Components/Flowcom/Flowslide'
import Headerflow from '../Components/Header/Header'
import Network from '../Components/Network/Network'
import Projectspot from '../Components/ProjectSpotlight/Projectspot'
import Blogs from '../Components/FeatureBlogs/Blogs';
import Footer from '../Components/Footer/Footer';
import Dumycard from '../Components/Dumycard/Dumycard';

export default function Home() {
  return (
    <div className='container-flow'>
      <Headerflow/>

          <Walletcontent/>
          {/* <PauseOnHover/>  */}
          <DeveloperBuilding/> 
          <Community/>
          <Dumycard/>
          <Network/>
          <CaseStudy/>
          <Projectspot/>
          <Blogs/>
          <Footer/>
    </div>
  )
}
