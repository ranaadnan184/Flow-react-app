import React from 'react'
import Favouritscom from '../Favouritescommunity/Favouritscom'
import Flowerheader from '../flowerHeader/Flowerheader'
import Noteablecard from '../NoteableProject/Noteablecard'
import Blockdevelop from '../Blockchaindeveloper/Blockdevelop'

export default function Flowercontainer() {
  return (
    <div>

        <Flowerheader/>
        <Noteablecard/>
        <Favouritscom/>
        <Blockdevelop/>
    </div>
  )
}
