import React from 'react'
import './style.css'

import img from '../../images/fllogo.png'
import img1 from '../../images/flovernft.png'
import img3 from '../../images/flovergif.gif'
import img4 from '../../images/publicogo.png'
export default function Flowerheader() {
  return (
    <div >
    <div className='flow-nav-parent'>
     <div className='flow--inner-nav'>
     <div className='navflow-logo-11'>
       <img src={img}/>

     </div>
       <input type="text" placeholder='search'/>
      
       <a href='#'>Learn </a>
       <a href='#'>Projects </a>
       <a href='#'>NFTs </a>
       <a href='#'>Jobs </a>
       <a href='#'>Resources </a>
       <a href='#'>Giveaways </a>
       <a href='#'>List Project </a>
       </div>
       </div>

       <div className='flow-nft-head'>
       <div className='flow-nft-inner'>
         <img src={img1}/>
         <span>The Flowverse Mystery Pass Public Sale is live Now</span>
         </div>

       </div>
       <div className='content-flover-parent'>
         <div className='content-flover-left'>
        <h1>Discover the hottest Flow Blockchain projects</h1>
        <p>Flowverse is the central hub to discover everything on Flow Blockchain including NFTs, games, DeFi and more</p>
         <button>Discover flow Project</button><br></br>
         <a>Learn more about Flowverse and Flow Blockchain</a>
         </div>
         <div className='content-flover-right'>
          <div className='gif-fllower-image'>
          <img src={img3}/>
         </div>
         <div className='public-sale'>
            <div className='sale-left'><img src={img4}/></div>
            <span id='inner-span'>
                <h4>Flowverse Mystery pass</h4>
                <span>Public Sale is live now</span>
                </span>
         </div>
       </div>
    </div>
    </div>
  )
}
