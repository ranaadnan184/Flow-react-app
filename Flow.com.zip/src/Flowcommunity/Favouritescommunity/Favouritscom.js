import React from 'react'
import './style.css'
import Faviroutdata from './Faviroutdata'
export default function Favouritscom() {
  return (
    <div>
    <div className='favrit-heading'>
        <h1>Flowverse Community Favourites</h1>
        <p>As voted by Flowverse Sock NFT holders</p>
    </div>

        <div className='parent-faviroute-card'>
           {
            Faviroutdata.map((item)=>{
                return(
                    <div className='inner-faviroute-card'>
            <div className='fav-image-11'> <img src={item.Fpic}/></div>
             <div className='fav-title-1'>
               <div id='text-fav-11'> <span id='first-text-1'>{item.Fname}</span><br></br>
                <span>{item.Fdes}</span></div>
             </div>
            </div>
                )
            })
           }
        </div>
    </div>
  )
}
