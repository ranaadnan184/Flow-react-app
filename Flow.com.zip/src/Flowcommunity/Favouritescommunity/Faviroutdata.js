import img1 from '../../images/notepic1.jpeg'
import img2 from '../../images/notepic2.jpeg'
import img3 from '../../images/notepic3.jpg'
import img4 from '../../images/notepic4.png'
import img5 from '../../images/nftpic1.jpg'
import img6 from '../../images/nftpic2.jpeg'
import img7 from '../../images/nftpic3.png'
import img8 from '../../images/nftpic4.png'
import img9 from '../../images/notepic4.png'



const Faviroutdata=[
    {
     Fpic:img1,
     Fname:"FLOAT",
     Fdes:"A Flow-enabled proof of attendance platform built by Emerald DAO"
},
{
    Fpic:img2,
    Fname:"Genious",
    Fdes:"A digital avatar company that will be launching its marketplace on Flow"
},
{
    Fpic:img3,
    Fname:"Matrix World",
    Fdes:"A 3D Programmable Multichain Metaverse"
},
{
    Fpic:img4,
    Fname:"FlowaTar",
    Fdes:"An NFT world where users can create their own characters in any creative and fun way they like"
},
{
    Fpic:img5,
    Fname:"NFL all Day",
    Fdes:"Digital video collectibles of Iconic NFL Moments by Dapper Labs"
},
{
   Fpic:img6,
   Fname:"Dimenssion X",
   Fdes:"Original card project which started on ETH but is now evolving on Flow"
},
{
   Fpic:img7,
   Fname:"Ballerz",
   Fdes:"BALLERZ is a basketball-inspired generative NFT set on Flow "
},
{
   Fpic:img8,
   Fname:"Gagia Marketplace",
   Fdes:"A Flow NFT marketplace powered by NFT Genius"
},
{
    Fpic:img9,
    Fname:"Increment FI",
    Fdes:"Decentralized money market and one-stop DeFi suites to boost yield & liquidity opportunities on the Flow blockchain"
},
]





export default Faviroutdata;