import React from 'react'
import Footer from '../../Components/Footer/Footer'
import './style.css'

export default function Newsletter() {
  return (
    <div>
    <div className='news-letter-parent'>
      
      <div className='news-letter-inner'>
       <h1>Open Worlds</h1>
       <p>Get the latest news from the Flow ecosystem</p>
       <div className='input-text-letter'><input type="text" placeholder='search'/><button>Sign Up</button></div>
      </div>
    </div>
    <Footer/>
    </div>
  )
}
