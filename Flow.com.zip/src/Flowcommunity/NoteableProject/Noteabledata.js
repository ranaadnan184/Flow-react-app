import img1 from '../../images/notepic1.jpeg'
import img2 from '../../images/notepic2.jpeg'
import img3 from '../../images/notepic3.jpg'
import img4 from '../../images/notepic4.png'


const Notedata=[
    {
     npic:img1,
     nname:"Flovatar",
     ndec:"An NFT world where users can create their own characters in any creative and fun way they like"
},
{
    npic:img2,
    nname:"NFL ALL DAY",
    ndec:"Digital video collectibles of Iconic NFL Moments by Dapper Labs"
},
{
    npic:img3,
    nname:"UFC Strike",
    ndec:"Own the best Moments from UFC history as officially licensed digital collectibles"
},
{
    npic:img4,
    nname:"NBA Top Shot",
    ndec:"Buy, sell, and collect Officially Licensed NFTs of NBA highlights called moments"
},
]


export default Notedata;