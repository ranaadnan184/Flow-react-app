import img1 from '../../images/nftpic1.jpg'
import img2 from '../../images/nftpic2.jpeg'
import img3 from '../../images/nftpic3.png'
import img4 from '../../images/nftpic4.png'


const Nftdata=[
    {
     ftpic:img1,
     ftname:"World Stars” Drop",
     ftprice:32
},
{
    ftpic:img2,
    ftname:"lil miquela",
    ftprice:"TBA"
},
{
    ftpic:img3,
    ftname:"CONSTRUCTION SITE COLLECTION",
    ftprice:"TBA"
},
{
    ftpic:img4,
    ftname:"BITE ME COLLECTION",
    ftprice:"TBA"
},
]


export default Nftdata;