import React from 'react'
import Notedata from './Noteabledata'
import Nftdata from './NFTdata'
import img2 from '../../images/nftlogo.png'
import './style.css'

export default function Noteablecard() {
  return (
    <div>

     <div className='note-heading'><h1>Notable Flow Projects</h1></div>
     <div className='node-able-parent-card'>
  
      {
        Notedata.map((item)=>{
            return(
                <div className='node-able-inner-card'>
                 <div className='note-inner-pic'><img src={item.npic}/></div>
                 <h3>{item.nname}</h3>
                 <p>{item.ndec}</p>
                  </div>
            )
        })
      }
     </div>

<div>
<div className='note-heading'>
<h2>Upcoming Flow NFT drops</h2>
<p>Flow Blockchain NFT Sales Calendar</p>
</div>
<div className='node-able-parent-card'>
  
  {
    Nftdata.map((item)=>{
        return(
            <div className='node-able-inner-card'>
             <div className='note-inner-pic'><img src={item.ftpic}/></div>
             <h3>{item.ftname}</h3>
             <div className='set-nft-icon'>From-Flow<img id='nft-logo' src={img2}/></div>
             <p>{item.ftprice}</p>
            </div>
        )
    })
  }
 </div>
 <div className='btn-nft-drop'><button>Explore NFT Drops</button></div>
</div>

<div className="newsletter-parent">
    <div className="newsletter-inner">
        <h3>Get the 5-minute weekly newsletter delivering 20,000+ people the latest alpha and news before everyone else</h3>
        <p>T&Cs and Privacy Policy. Unsubscribe anytime.</p>
         
         <div className='btn-rmail-adress'>
            <input type="text" placeholder='Email Address'/> 
            <button>Subscribe</button>
         </div>
    </div>
</div>
    </div>
  )
}
