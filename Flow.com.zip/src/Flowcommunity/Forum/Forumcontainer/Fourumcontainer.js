import React from 'react'
import Newsletter from '../../NewsLetter/Newsletter'
import ForumCategory from '../Category/ForumCategory'
import Forumheader from '../Header/Forumheader'

export default function Fourumcontainer() {
  return (
    <div>

    {/* <Forumheader/>
     <ForumCategory/> */}

     <Newsletter/>
    </div>
  )
}
