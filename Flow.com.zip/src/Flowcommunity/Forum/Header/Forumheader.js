import React from 'react'
import './style.css'

import img from '../../../images/nftlogo.png'
import { FaSearch } from 'react-icons/fa';
import { TbMenu2 } from 'react-icons/tb';
export default function Forumheader() {
  return (
    <div>
        <div className='Forum-nav-1'>
           <div className='Forum-left-1'>
             <img src={img}/>
             <span>Flow</span>
           </div>
           <div className='Forum-right-1'>
            <button>Sign Up</button>
            <button>Log In</button>

       
             <FaSearch id="iconheas-search-1" /> 
             <TbMenu2 id="iconheas-search-1" />  
         

           </div>
         </div>
         <div className='second-nav-forum'>
            <div>

              <select name="Catrgories" id="All Catrgories"> 
              <option value="Catrgories">All Catrgories</option>
              <option value="Flow">New to Flow</option>
              <option value="Announcement">Announcement</option>
               <option value="ideas">Product and ideas</option>
               <option value="Project">Community Project</option>
               </select>
               </div>
               <div>

              <select name="tags" id="tags">
              <option value="tags">All tags</option>
              <option value="tags">No-tags</option>
              <option value="tags">flow-sdk-js</option>
              <option value="tags">flow-sdk-go</option>
              <option value="tags">Candenance</option>
              </select>
              </div>
              <button>Categories</button>
              <button>Latest</button>
              <button>Top</button>
         </div>
    </div>

  )
}
