import React from 'react'
import './style.css'

// import Faviroutdata from '../../Favouritescommunity/Faviroutdata'
import Fcategorydata from './Fcategorydata'
export default function ForumCategory() {
  return (
    <div>

        <div className='parent-category-card'>
               
        {
            Fcategorydata.map((item)=>{
                var color=item.col

                {/* console.log(color,"sasddsa") */}
                return(
                 <div style={{borderLeft:  `3px solid ${color}` }} className='inner-card-category'>
                 {item.Cpic?<img src={item.Cpic}/>:""}
                  
                  <div className='inner-text-category'>
                  <span id='car-title-1' >{item.title}</span>
                  <div id='car-title-2'>{item.des}</div>

                  <p id='text-detail-1'>{item.detail}</p> </div>
                  <div className='inner-num-category'>
                  <i>{item.number}</i>
                  <p>{item.date}</p>
               </div>
               </div>
                )
            })
        }

        </div>
    </div>
  )
}
