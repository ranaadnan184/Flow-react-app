import Img from "../../../images/catpic1.png"
import Img1 from "../../../images/catpic2.png"
import Img2 from "../../../images/catpic3.png"
import Img3 from "../../../images/catpic4.png"



const Fcategorydata= [
    {
      Cpic:"",
      title:"New To Flow",
      detail:"If you’re new to Flow introduce yourself here!",
      number:"99",
      date:"",
      col:"#26FF76"

},
{
    Cpic:Img,
    title:"",
    col:"",

    des:"Which Company Provides the Best Cryptocurrency wallet development Services?",
    detail:"Product & Ideas Fcl",
    number:"0",
    date:"8D"

},
{
    Cpic:"",
     col:"#F7941D",
    title:"Announcements",
    detail:"Hear ye, hear ye!  Friends, Flowmans, lend me your ears!",
    number:"70",
    date:"Flow Ecosystem  NewsLetter"

},
{
    col:"",
    Cpic:Img1,
    title:"",
    des:"FLIP: Cadence Extensions/Attachments",

    detail:"Flips Candenance",
    number:"22",
    date:"9D"

},
{
    col:"#0088CC",
    Cpic:"",
    title:"Product & Ideas",
    detail:"In this category you can discuss about your ideas, product strategies, get peer feedback and more.",
    number:"11",
    date:""
    
},
{
    col:"",
    Cpic:Img2,
    title:"",
    des:"Flow Mainnet spork underway",
    detail:"Mainnet Sporks",
    number:"1",
    date:"10D"

},
{
    col:"#9EB83B",
    Cpic:"",
    title:"Community Projects",
    detail:"CryptoDappy",
    number:"6",
    date:""

},
{
    col:"",
    Cpic:Img3,
    title:"",
    des:"Mismatched types error",
    detail:"New To Flow  Candenance",
    number:"0",
    date:"11D"

},

]

export default Fcategorydata 