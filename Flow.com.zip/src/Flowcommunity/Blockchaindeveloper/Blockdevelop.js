import React from 'react'
import './style.css'
import { FaDiscord } from "react-icons/fa";
import { BsTwitter } from "react-icons/bs";
import { MdMessage } from "react-icons/md";
import { BsMessenger } from "react-icons/bs";

export default function Blockdevelop() {
  return (
    <div>
        <div className='view-all-parent'>
        <h1>All Flow Blockchain Projects</h1>
           <div className='viw-all'>
           <a>View All 300+ Flow blockchain Project  </a>
           </div> 
           <div className='viw-all-1'>
           <a>View  Flow blockchain Project Ranked By Primary And Secondary Sales   </a>
           </div>
           <div className='viw-all-1'>
           <a>View All 100+ NFT Collection On flow Blockchain </a>
           </div>
           <div className='viw-single-parent'>
           <div className='viw-single-1'>
           <a>Analytics tool </a>
           </div>
           <div className='viw-single-1'>
           <a>Art </a>
           </div>
           <div className='viw-single-1'>
           <a>Avatar </a>
           </div>
           <div className='viw-single-1'>
           <a>Black creator fund on flow </a>
           </div>
           <div className='viw-single-1'>
           <a>Buy with flow </a>
           </div>
           <div className='viw-single-1'>
           <a>Collectibles </a>
           </div>
           <div className='viw-single-1'>
           <a>DAOs </a>
           </div>
           <div className='viw-single-1'>
           <a>Dapper stodio Ecosystem </a>
           </div>
           <div className='viw-single-1'>
           <a>Dapper wallet </a>
           </div>
           <div className='viw-single-1'>
           <a>Defi </a>
           </div>
           <div className='viw-single-1'>
           <a>Education </a>
           </div>
           <div className='viw-single-1'>
           <a>Exchanges  </a>
           </div>
           <div className='viw-single-1'>
           <a>Fashion  </a>
           </div>
           <div className='viw-single-1'>
           <a>Galleries </a>
           </div>
           <div className='viw-single-1'>
           <a>Games </a>
           </div>
           <div className='viw-single-1'>
           <a>Marketplaces </a>
           
           </div>
           <div className='viw-single-1'>
           <a>Mobile </a>
           </div>
           <div className='viw-single-1'>
           <a>Music </a>
           </div>
           <div className='viw-single-1'>
           <a>Social </a>
           </div>
           <div className='viw-single-1'>
           <a>Sports</a>
           </div>
           <div className='viw-single-1'>
           <a>Tockens </a>
           </div>
           <div className='viw-single-1'>
           <a>Tools </a>
           </div>
           <div className='viw-single-1'>
           <a>Trending </a>
           </div>
           <div className='viw-single-1'>
           <a>Wallets </a>
           </div>
           </div>
           <div id='footer-text'>
           <p><b>DISCLAIMER:</b> All content provided herein our website, hyperlinked sites, associated applications, forums, blogs, social media accounts and other platforms is for your general information only, procured primarily from third party sources. Flowverse does not warrant the accuracy, security and up-datedness of this information. The information should not be construed as professional or financial advice of any kind. Any use or reliance on our content and services is solely at your own risk and discretion.</p>
             
             <div >
                <h3>Made with 💚 and ☕ by the community team at Flowverse</h3>
                  <div className='icon-footer-flov-parent'>
                  <div className='icon-footer-flov'>
                    <FaDiscord color='blue' size={40}/>
                   <BsTwitter color='blue' size={40}/>
                   <MdMessage color='blue' size={40}/>
                   <BsMessenger color='blue' size={40}/>
                  </div>
                  </div>
             </div>
             <div id='flov-footer-left'>
             <a>Flowverse © 2021</a>
             <a>List my Flow project</a>
            <a>List my Flow drop</a>
             <a>Update Flow sales rankings</a>
             <a>FAQ</a>
             <a>Terms of use</a>
             <a>Privacy Policy</a>
             <button id='follow-btn-1'>Follow @Flowverse</button>
             <button id='follow-btn-2'>41.5 @Followerse</button>
             </div>
        </div>
        </div>
    </div>
  )
}
