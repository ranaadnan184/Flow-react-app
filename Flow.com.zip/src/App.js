import "./App.css";

import Blogcontainer from "./Blogs/Contaner/Blogcontainer";
import Container from "./Container/Container";
import Container2 from "./Container2/Container2";
import { Routes, Route, BrowserRouter as Router } from "react-router-dom";
import Blogheader from "./Blogs/Header/Blogheader";
import Maincard from "./Blogs/MainCard/Maincard";
import DevCard from "./Blogs/MainCard/Devcard/DevCard";
import EducationCard from "./Blogs/MainCard/Educationcard/EduCard";
import Headerflow from "./Components/Header/Header";
import Home from "./Container/Container";
import Developer from "./Container2/Container2";
import AllCards from "./Blogs/Contaner/Blogcontainer";
import EcofundContainer from "./EcosystemFund/EcofundContainer";
import Nodecontainer from "./Nodemodule/Learnmore/Nodecontainer";
import Contact from "./Contact/Contact";
import Flowercontainer from "./Flowcommunity/flowercontainer/flowercontainer";
import Fourumcontainer from "./Flowcommunity/Forum/Forumcontainer/Fourumcontainer";
import Dumycard from "./Components/Dumycard/Dumycard";
// import FLOWamcontainer from "./Flowcommunity/Flowambassador/FLOWamcontainer";

function App() {
  return (
    <div className="App">
      {/* <Container/> */}

      <Router>
     

        {/* <Container2/> */}

        {/* <Blogcontainer/> */}

        {/* Main container of compunent */}
        {/* <Headerflow/> */}

        {/* <EcofundContainer/> */}

        {/* <Nodecontainer/> */}
        {/* <Contact/> */}
        {/* <Flowercontainer/> */}
        {/* <Fourumcontainer/> */}
        {/* <Home/> */}

        <Routes>
          {/* <Route  path="/" element={<Home/> } />  */}
          {/* <Route  path="/Maincard" element={<Maincard/> } />  */}
          {/* <Route path="/All" element={<AllCards />} />
          <Route path="/DevCard" element={<DevCard />} />
          <Route path="/EduCard" element={<EducationCard />} />
          <Route path="/Blogheader" element={<Blogheader />} />
          <Route path="/Developer" element={<Developer />} /> */}
        </Routes>
      </Router>
    </div>
  );
}

export default App;
