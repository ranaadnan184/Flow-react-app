import React from 'react'
import Devnavbar from '../Componentsdeveloper/Devnavbar/Devnavbar'
import Devportal from '../Componentsdeveloper/Devportal/Devportal'
import Flips from '../Componentsdeveloper/Flips/Flips'
import Footerdev from '../Componentsdeveloper/Footer/Footer'
import Morecontent from '../Componentsdeveloper/Morecontent/Morecontent'
import Quick from '../Componentsdeveloper/Quickstart/Quick'
import Tool from '../Componentsdeveloper/Tool/Tool'

export default function Developer() {
  return (
    <div>
      <Devnavbar/>
      <Devportal/>
      <Quick/>
      <Tool/>
      <Flips/>
      <Morecontent/>
      <Footerdev/>

    </div>
  )
}
