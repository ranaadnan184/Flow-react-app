import React from 'react'
import { GrSearch} from "react-icons/gr";
import { BiWifi} from "react-icons/bi";
import './style.css';
import { Link } from 'react-router-dom';

export default function Blogheader() {
  return (
    <div>  
       <div className='headin-blog'> <h2>BLOG</h2></div>
          <div className='main-blog-navbar'>
     
      <div className='left-blog'>
       <Link to='/All'>All</Link>
       <Link to='/Maincard'>Ecosystem</Link>
       <Link to='/EduCard'>Developer</Link>
       <Link to='/DevCard'>Education</Link>
      </div>
      <div className='right-blog'>
        <input id='th' type="text" placeholder="Search"/>
       <a href='#'><GrSearch id='icon-nav'/></a>
       <a href='#'><BiWifi  id='icon-nav'/></a>

      </div>
    </div>
    </div>
  )
}
