import React from 'react'
// import Bcard from '../BlogCard/Bcard'
import Maincard from '../MainCard/Maincard'
import Blogheader from '../Header/Blogheader'
import DevCard from '../MainCard/Devcard/DevCard'
import EducationCard from '../MainCard/Educationcard/EduCard'

export default function AllCards() {
  return (
    <div>

<Blogheader/>

<Maincard/>
      <DevCard/>
      <EducationCard/>


   
    </div>
  )
}
