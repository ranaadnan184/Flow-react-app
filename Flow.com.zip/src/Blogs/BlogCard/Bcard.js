import React from 'react'
import img7 from '../../images/cardleft.jpeg'
// import './style.css';
export default function Bcard() {
  return (
    <div>
      <div className='main-div-card'>
        <div className='div-card'>
            <div className='left-side'>
             <img src={img7}/>
            </div>
            <div className='right-side'>
             <button>
                Featured
             </button>
             <span>
             <p>Developer <i>july 5,2022</i></p>
              <h5>Permissionless smart contract Deployment is live on flow</h5>
             <span>Permissionless smart contract Deployment is live on flow</span></span>

            </div>
        </div>
      </div>
    </div>
  )
}
