import React from 'react'
import img7 from '../../../images/devpicmain.png'
import '../../MainCard/style.css';
import '../../MainCard/Card.css';

import DevData from './DevData';
import Footer from '../../../Components/Footer/Footer';
// import Blogheader from '../../Header/Blogheader';
export default function DevCard() {
  return (
    <div>
  
  <div className='main-div-card'>
        <div className='div-card'>
            <div className='left-side'>
             <img src={img7}/>
            </div>
            <div className='right-side'>
             <button>
                Featured
             </button>
             <span>
             <p>Developer <i>feb 2,2021</i></p>
              <h5>How to grow a community around your project</h5>
             <span>In the decentralized world, communities can make or break any startup. To create trust in a trustless environment is a cumbersome but well worth task. This guide seeks to provide the reader with some of the necessary understanding.</span></span>

            </div>
        </div>
      </div>

      
      <div className="main-card-12">
      {DevData.map((item) => {
        return (
            <div className=" ">
              <div className="ambadassor-card">
                <img src={item.pic} />
                <span>
                  {item.name}
                  <i>{item.date}</i>
                </span>
                <span>
                  <h5>{item.title}</h5>
                  <p>{item.des}</p>
                </span>
              </div>
              </div>
             
        );
      })}
  </div>
  <Footer/>
    </div>
  )
}
