import img1 from '../../../images/devpic1.png'

import img2 from '../../../images/devpic2.png'

import img3 from '../../../images/decpic3.jpeg'

import img4 from '../../../images/devpic4.png'

import img5 from '../../../images/devpic5.png'
import img6 from '../../../images/devpic6.png'



const DevData=[
    {
        pic:img1,
        name:"Education",
        date:"october 13, 2022",
        title:"Guide: Fungible Tokens on Flow",
        des:"How do fungible tokens work on Flow? Learn all about it inside and find our in-depth Fungible Tokens on Flow guide!"
    },
    {
        pic:img2,
        name:"Education",
        date:"september 18, 2021",
        title:"Inside Flow: The Multi-Node Architecture that Scales to Millions",
        des:"By introducing the paradigm of pipelining through specialised node types, Flow’s multi-node architecture provides higher levels of throughput and decentralisation than existing solutions, while significantly enhancing ease of development, user experience and digital asset security , without relying on sharding or layer 2 solutions. It’s the blueprint for future-proof consumer-grade blockchain protocols."
    },
    {
        pic:img3,
        name:"Education",
        date:"May 6, 2021",
        title:"Flow Partnerships: Insights into Music",
        des:"What kind of experiences do artists and labels across the music industry want to create with blockchain technology, how do different elements of music fit into what kind of NFTs can be created, and what should builders be thinking about as they consider opportunities in this space? Learn all about it."
    },
    {
        pic:img4,
        name:"Ecosystem",
        date:"Feb 2, 2021",
        title:"How to grow a community around your project",
        des:"In the decentralized world, communities can make or break any startup. To create trust in a trustless environment is a cumbersome but well worth task. This guide seeks to provide the reader with some of the necessary understanding."
    },
    {
        pic:img5,
        name:"Ecosystem",
        date:"Jan 21, 2021",
        title:"Supply chain management and blockchain technology",
        des:"The supply chain management industry has for long struggled with various problems reducing the efficiency with which a product gets to the end user’s hands. Causing global disruptions, the 2020 pandemic further exposed these issues, to which blockchain technology may be the needed answer."
    },
    {
        pic:img6,
        name:"Ecosystem",
        date:"Jan 7, 2021",
        title:"How to fund a blockchain startup?",
        des:"In every startup’s journey, a moment comes when the question “How to fund it?” demands an answer. The answer will necessarily be different depending on the industry the startup finds itself in, and this dependence seems to play an even larger role when referring to the blockchain space."
    }
];


export default DevData
