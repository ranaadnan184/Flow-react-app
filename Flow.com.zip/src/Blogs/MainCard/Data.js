import img1 from '../../images/mcard.jpg'
import img2 from '../../images/mcard2.png'
import img3 from '../../images/mcard3.png'
import img4 from '../../images/mcard4.png'
import img5 from '../../images/mcard5.png'
import img6 from '../../images/mcard6.jpeg'


const Carddata=[
    {
        pic:img1,
        name:"Ecosystem",
        date:"July 22, 2022",
        title:"spotlight: enter the rogue Bunnies mansion",
        des:"These former Playboy Playmates have gone rogue are opening up their very own mansion. Meet The Rogue Bunnies."
    },
    {
        pic:img2,
        name:"Ecosystem",
        date:"July 22, 2022",
        title:"Partner Spotlight: Find your metaverse best friend with SolarPups",
        des:"Ready to find your perfect SolarPup, then play fetch with them in augmented reality? SolarPups takes a page out of the Cryptokitties playbook, creating a dog breeding and collecting experience that's out of this world!."
    },
    {
        pic:img3,
        name:"Ecosystem",
        date:"July 22, 2022",
        title:"Flow Network Status Updates: Sporks, Status Page, and Where to Find Info",
        des:"Want to know where to look to keep up with all Flow network status updates? Here's a few key places to bookmark and information for you!"
    },
    {
        pic:img4,
        name:"Ecosystem",
        date:"July 22, 2022",
        title:"Partner Spotlight: Jolly Jokers; Web3 Sports Community, Utility, & Gamification from Own the Moment",
        des:"Own The Moment is bringing utility to NBA Top Shot and NFL ALL DAY holders with the Jolly Jokers."
    },
    {
        pic:img5,
        name:"Ecosystem",
        date:"July 22, 2022",
        title:"Permissionless Smart Contract Deployment is live on Flow",
        des:"Permissionless smart contract deployment is LIVE on Flow."
    },
    {
        pic:img6,
        name:"Ecosystem",
        date:"July 22, 2022",
        title:"Partner Spotlight: Bobblz brings bobbleheads to life through Web3",
        des:"Bobbleheads are shaking the dust of from the shelf they've been on and are making the jump to Web3 with Bobblz; an innovative and evolutionary premium NFT experience on Flow."
    }
];


export default Carddata
