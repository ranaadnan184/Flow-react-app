import img1 from '../../../images/Edu1.jpg'
import img2 from '../../../images/Edu2.png'
import img3 from '../../../images/edu3.png'
import img4 from '../../../images/edu4.jpeg'
import img5 from '../../../images/edu5.jpeg'
import img6 from '../../../images/edu6.png'


const EducationData=[
    {
        pic:img1,
        name:"Developer",
        date:"august 19, 2020",
        title:"Cadence Developer Survey: Building on Flow",
        des:"Participate in our community survey and get a special FLOAT."
    },
    {
        pic:img2,
        name:"Developer",
        date:"July 21, 2022",
        title:"Flow Network Status Updates: Sporks, Status Page, and Where to Find Info",
        des:"Want to know where to look to keep up with all Flow network status updates? Here's a few key places to bookmark and information for you!"
    },
    {
        pic:img3,
        name:"Developer",
        date:"July 5, 2022",
        title:"Permissionless Smart Contract Deployment is live on Flow",
        des:"Permissionless smart contract deployment is LIVE on Flow."
    },
    {
        pic:img4,
        name:"Developer",
        date:"April 21, 2022",
        title:"‍Build your own NFT Marketplace in 10 minutes",
        des:"Learn how to build your own NFT marketplace on Flow with the new Kitty Items update and video walkthrough. Inspired by CryptoKitties"
    },
    {
        pic:img5,
        name:"Developer",
        date:"July 14, 2022",
        title:"Inside Flow: Cadence, The Language Made For Digital Assets",
        des:"Cadence is a smart contract programming language specifically designed for managing ownership of digital assets of value, like art, collectibles or cryptocurrencies. In Cadence, digital assets are first-class citizens, making their accidental loss or malicious duplication impossible while providing fine-grained and human-readable access control. It’s a language that is faster to learn, easier to audit, and more productive."
    },
    {
        pic:img6,
        name:"Developer",
        date:"Jun 10, 2022",
        title:"Inside Flow: The Power of Simplicity with FCL",
        des:"The Flow Client Library (FCL) empowers developers to build blockchain-enabled applications faster than ever, revolutionizing the interaction between frontends, smart contracts and wallets — it’s a new tool for a new generation of builders. Now that FUSD is live on Flow mainnet, FCL is officially the recommended way to build on Flow."
    }
];


export default EducationData
