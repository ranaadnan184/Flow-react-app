import React from "react";
// import img from '../../images/mcard.jpg'
import "../../MainCard/Card.css";
import '../style.css';
import img7 from '../../../images/cardleft.jpeg'

import EducationData from "./EducationData";
import Footer from "../../../Components/Footer/Footer";

export default function EducationCard() {
  return (
  <>
    <div className='main-div-card'>
        <div className='div-card'>
            <div className='left-side'>
             <img src={img7}/>
            </div>
            <div className='right-side'>
             <button>
                Featured
             </button>
             <span>
             <p>Education <i>july 5,2022</i></p>
              <h5>Permissionless smart contract Deployment is live on flow</h5>
             <span>Permissionless smart contract Deployment is live on flow</span></span>

            </div>
        </div>
      </div>
  <div className="main-card-12">
      {EducationData.map((item) => {
        return (
            <div className=" ">
              <div className="ambadassor-card">
                <img src={item.pic} />
                <span>
                  {item.name}
                  <i>{item.date}</i>
                </span>
                <span>
                  <h5>{item.title}</h5>
                  <p>{item.des}</p>
                </span>
              </div>
              </div>
             
        );
      })}
  </div>
  <Footer/>
</>
  
  );
}
