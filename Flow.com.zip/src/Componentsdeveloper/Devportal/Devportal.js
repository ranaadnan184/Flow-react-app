import React from 'react'
import img from '../../images/rightdev.png'
import './style.css';
import img1 from '../../images/logoflow.png'

export default function Devportal() {
  return (
    <>
        <div className='inner-portal'>

    <div className='dev-portal-main'>
      <div className='left-portal'>
    <h2>#onflow</h2>
    <h1>Developer Portal</h1>
    <p>Discover the developer ecosystem and master the Flow blockchain</p>
      </div>
      <div className='right-portal'>
       <img src={img}/>
      </div>
      </div>
      <div className='inner-project'>
       <div className='left-project'>
        <span>#onflow</span>
        <h1>Start Your Project</h1>
   <p>
Building on Flow is easy. Start building now on web3 with the power of resource-oriented programming, multi-node architecture, and a host of other features and tooling to make your dapp development easy and efficient.</p>
       <button>Get Started</button>
       </div>
       <div className='right-project'>
        <div className='right-1'>
         <img src={img1}/>
         <span>
            <h3>Flow Quick</h3>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Repellendus ipsa quaerat delen Repellendus ipsa quaerat delen</p>
         </span>
        </div>
        <div className='right-1'>
        <img src={img1}/>
         <span>
            <h3>Learn Smart Contracts</h3>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Repellendus ipsa quaerat delen Repellendus ipsa quaerat delen</p>
            
            
            <div className='info-right'>
                <a href='#'>Helo, World</a>
                <a href='#'>NFTs</a>
                <a href='#'>Marketeplace</a>
            </div>
            
            
            

         </span>
        </div>
       </div>
      </div>
    </div>
    </>
  )
}
