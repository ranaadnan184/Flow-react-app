import React from 'react';
import './style.css';

import { AiOutlineGithub} from 'react-icons/ai';

import img from '../../images/logoflow.png'

import { MdForum} from 'react-icons/md';
import { SiTwitter} from 'react-icons/si';
import { SiDiscord} from 'react-icons/si';
export default function Footerdev() {
  return (
    <div className='main-foot'>
      <div className='footer-nav'>
        <di className="inner-nav">
            <div className='nav-left'><img src={img}/>
            <p><b>Flow</b>developer</p></div>
            <span>
             <AiOutlineGithub size={30}/>
             <SiTwitter size={30}/>
             < MdForum size={30}/>
             <SiDiscord size={30}/>
            </span>
        </di>

      </div>
      <hr style={{width:"80%"}}/>


        <div className='content-footer-parent'>
            <div className='innet-111'>
              <div className='inner-content'>
                
                    <h4>Documentation</h4>
                    <p>Getting Started</p>
                      <p>  SDK's & Tools</p>
                      <p> Learning Resources</p>
                       <p>  Cadence</p>
                     
                       <p>Emulator</p>
                      <p> Dev Wallet</p>
                      <p> VS Code Extension</p>
              
                </div> 
            
            <div className='inner-content'>
                
                <h4>Community</h4>
                <p>Getting Started</p>
                  <p>  SDK's & Tools</p>
                  <p> Learning Resources</p>
                   <p>  Cadence</p>
                
                   <p>Emulator</p>
                  <p> Dev Wallet</p>
                  <p> VS Code Extension</p>
          
            </div> 
            </div>
            <div className='innet-111'>
            
            <div className='inner-content'>
                
                <h4>Start Building</h4>
                <p>Getting Started</p>
                  <p>  SDK's & Tools</p>
                  <p> Learning Resources</p>
                   <p>  Cadence</p>
                     <p> FCL</p>
                     <p>   JS Testing Library</p> 
               
          
            </div> 
          
          
            <div className='inner-content'>
                
                <h4>Network</h4>
                  <p>Getting Started</p>
                   <p>  SDK's & Tools</p>
                   <p> Learning Resources</p>
                   <p>  Cadence</p>
                  
                  <p> VS Code Extension</p>
          
        
            </div>
            </div>

        </div>
      <hr style={{width:"80%"}}/>
      <p id='id2022'>@2022 Flow</p>

    </div>
  );
}
