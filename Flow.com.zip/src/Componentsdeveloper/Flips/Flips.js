import React from 'react'
import './style.css';
import img from '../../images/circle.jfif'
import img1 from '../../images/usertom.png'
import { SlCalender} from 'react-icons/sl';
import { FiMessageCircle} from 'react-icons/fi';

export default function Flips() {
  return (
    <dic className="flip---1">
    <div className='flips-main'>
      <div className='flip-1'>
        <div className='heading-flip'>
         <div className='btn---1'> <h1>FLIPs</h1>
           <button type='button'> Go to Github</button>
         </div>
           <p>
            Go to GitHub
            Flow improvement proposals can be submitted through a PR and are intended to propose changes to Flow's network and standards</p></div>
          
      </div>
    </div>
    <div className='flips-main'>
      <div className='flip-2'>
      
          <span id='open-file'><h3>Open Files</h3>
           <p>
            Good places
            </p>

            </span>
      </div>

    </div>
    <hr style={{width:"80%"}}/>
    <div className='maintext'>
        <div className='innettext'>
            <div className='lefttext'>
             <span>Topic</span>
            </div>
               <div className='righttext'>
                
               <i>Submitted by</i>
                    <i>Repositry</i>
                    <i>Date Submitted</i>
                    <i>Comments</i>
                
                </div>
        </div>
    </div>
    <div className='flips-main'>
      <div className='flip-3'>
      
         <div className='flip3-left'>
         <img src={img}/>

         <span>
            <h4>Flip: Capapality controller</h4>
            <p id='fliptext'><i>#Flips</i>  <i>#Cadence</i>  <i>#S-Governance</i></p>
         </span>
         </div>
        
        
         <div className='flip3-right'>
            <span>
                <img id='user-img' src={img1}/>
                <p id='danial'>danial malik</p>

            </span>
         <span id='fliptext1'>
            <i>Flow</i> <SlCalender id='icon11'  /> <i>20-11-11</i><FiMessageCircle id='icon12' />  <i>30</i>
         </span>
         </div>
        
      </div>

      

    </div>
    <div className='flips-main'>
    <div className='flip-3'>
      
      <div className='flip3-left'>
      <img src={img}/>

      <span>
         <h4>Flip: Candence brrowContract allow dynamic import</h4>
         <p id='fliptext'><i>#Flips</i>  <i>#Cadence</i></p>
      </span>
      </div>
     
     
      <div className='flip3-right'>
         <span>
             <img id='user-img' src={img1}/>
             <p id='danial'>danial malik</p>

         </span>
      <span id='fliptext1'>
         <i>Flow</i> <SlCalender id='icon11'  /> <i>20-11-11</i> <FiMessageCircle id='icon12'/> <i>30</i>
      </span>
      </div>
     
   </div>
   </div>
   <div className='flips-main'>
    <div className='flip-3'>
      
      <div className='flip3-left'>
      <img src={img}/>

      <span>
         <h4>Flip: Enable new feilds on existing resource and struckt definition</h4>
         <p id='fliptext'><i>#Flips</i>  <i>#Cadence</i></p>
      </span>
      </div>
     
     
      <div className='flip3-right'>
         <span>
             <img id='user-img' src={img1}/>
             <p id='danial'>danial malik</p>
         </span>
      <span id='fliptext1'>
         <i>Flow</i> <SlCalender id='icon11'  /> <i>20-11-11</i> <FiMessageCircle id='icon12' /> <i>30</i>
      </span>
      </div>
     
   </div>
   </div>
    </dic>
  )
}
