import React from 'react'
import img from '../../images/logoflow.png'
import './style.css';
import { GrSearch} from "react-icons/gr";
export default function Devnavbar() {
  return (
    <div className='main-dev-navbar'>
      <div className='left-dev'>
         <img src={img}/>
         <span>flow</span>
         <p>Developer</p>
      </div>
      <div className='right-dev'>
      <i><GrSearch id='icon-search' /></i> <a href='#'> Serach</a>
       <span id='check'><a href='#'>Documentation</a></span>
       <span id='check'><a href='#'>Community</a></span>
       <span id='check'><a href='#'>Network</a></span>
      </div>
    </div>
  )
}
