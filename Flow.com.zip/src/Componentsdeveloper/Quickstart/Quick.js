import React from 'react'
import { SiQuip } from 'react-icons/si';
import { BsArrowUpRight} from 'react-icons/bs';
import { IoIosArrowForward} from 'react-icons/io';
import './style.css';


export default function Quick() {
  return (
    <div>
      <div className='inner-quick'>
      <div className='left-quick'>
        <span>
            
            <h3><i><SiQuip/></i>Quickstarts</h3>
        </span>
        <p>Quick ways to get started in the environments for development.</p>
        <div className='inner-quick-1'>
            <span>
            <h5>Get started locally</h5>
            <BsArrowUpRight/>
            </span>
            <p>#emulator</p>
            <hr/>
        </div>
        <div className='inner-quick-1'>
            <span>
            <h5>Get started on testnet</h5>
            <IoIosArrowForward/>
            </span>
            <p>#javascript</p>
            <hr/>
        </div>   <div className='inner-quick-1'>
            <span>
            <h5>Get started on the playground</h5>
            <IoIosArrowForward/>
            </span>
            <p>#playground</p>
            <hr/>
        </div>
        <div className='inner-quick-1'>
            <span>
            <h5>View all tool and services </h5>
            <IoIosArrowForward/>
            </span>
            <hr/>
        </div>  
      </div>
      <div className='left-quick'>
      <span>
            
            <h3><i><SiQuip/></i>Guides and tutorials</h3>
        </span>
        <p>A more in-depth look at how dapp development works.</p>
        <div className='inner-quick-1'>
            <span>
            <h5>Anatomy of a Flow dapp</h5>
            <BsArrowUpRight/>
            </span>
            <p>#Overview</p>
            <hr/>
        </div>
        <div className='inner-quick-1'>
            <span>
            <h5>Flow key concept</h5>
            <IoIosArrowForward/>
            </span>
            <p><i>#accounting</i><i>#string</i></p>
            <hr/>
        </div>   <div className='inner-quick-1'>
            <span>
            <h5>Lounch a fangible tocken on Flow</h5>
            <IoIosArrowForward/>
            </span>
            <p><i>#overview </i><i>#guide</i></p>
            <hr/>
        </div>
        <div className='inner-quick-1'>
            <span>
            <h5>View more learning resources </h5>
            <IoIosArrowForward/>
            </span>
            <hr/>
        </div>  
      </div>
      <div className='left-quick'>
      <span>
            
            <h3><i><SiQuip/></i>Smart Contracts</h3>
        </span>
        <p>Use Cadence to interact with and create smart contracts on chain.</p>
        <div className='inner-quick-1'>
            <span>
            <h5> why Candence?</h5>
            <BsArrowUpRight/>
            </span>
            <p>#blog</p>
            <hr/>
        </div>
        <div className='inner-quick-1'>
            <span>
            <h5>Resouce Oriented pograming</h5>
            <IoIosArrowForward/>
            </span>
            <p>#overview</p>
            <hr/>
        </div>   <div className='inner-quick-1'>
            <span>
            <h5>Candence cookbook</h5>
            <IoIosArrowForward/>
            </span>
            <p><i>#sample </i><i>#playground</i></p>
            <hr/>
        </div>
        <div className='inner-quick-1'>
            <span>
            <h5>View all candence content </h5>
            <IoIosArrowForward/>
            </span>
            <hr/>
        </div> 
      </div>
      </div>
      <hr/>
    </div>
  )
}
