import React from 'react'
import { BsStarFill } from 'react-icons/bs';
import img from '../../images/logoflow.png'
import img1 from '../../images/powerlogo.jfif'
import img2 from '../../images/gosdk.png'
import img3 from '../../images/follo.jfif'
import img4 from '../../images/fragment.jfif'
import { BsArrowUpRight} from 'react-icons/bs';
import {  IoIosArrowForward} from 'react-icons/io';


import './style.css';

export default function Tool() {
  return (
    <div >
       <div className='heading123'><span id='heading'> <h1>Tools</h1>
        <p>
Some of our new and popular tooling to build on Flow.</p></span></div>
      <div className='tool-main'>
       
      <div className='tool-left'>
      <div className='inner-tool'>
         <img src={img1}/>
         <div className='tool-info'>
         <span>HTTP Api</span>
            
           <span>
           <span id='tool-span'>
          <br></br>
            <img src={img}/>
             <span>onfollow</span>
            <BsStarFill color="yellow"/>
            <i>553</i>
           </span>
           <br></br>
           <span id=''><i>#overview </i>  <i>#guide</i></span>
           </span>
         </div>
        </div>
        <div className='inner-tool'>
         <img src={img2}/>
         <div className='tool-info'>
         <span>Java script SDK (fCL)</span>
            
           <span>
           <span id='tool-span'>
          <br></br>
            <img src={img}/>
             <span>onfollow</span>
            <BsStarFill color="yellow"/>
            <i>353</i>
           </span>
           <br></br>
           <span><i>#Documentation </i> <i> #Active</i></span>
           </span>
         </div>
        </div>
        <div className='inner-tool'>
         <img src={img3}/>
         <div className='tool-info'>
         <span>Followers</span>
            
           <span>
           <span id='tool-span'>
          <br></br>
            <img src={img}/>
             <span>onfollow</span>
            <BsStarFill color="yellow"/>
            <i>53</i>
           </span>
           <br></br>
           <span><i>#GUI </i>  <i>#explorer</i>  <i>#local</i></span>
           {/* <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab perspiciatis, iure id</p> */}
           </span>
         </div>
        </div>
      </div>
      <div className='tool-left'>
         

           


      <div className='inner-tool'>
         <img src={img2}/>
         <div className='tool-info'>
         <span>Go SDK </span>
            
           <span>
           <span id='tool-span'>
          <br></br>
            <img src={img}/>
             <span>onfollow</span>
            <BsStarFill color="yellow"/>
            <i>553</i>
           </span>
           <br></br>
           <span><i>#Documentation </i> <i>#Active</i></span>

           </span>
         </div>
        </div>
        <div className='inner-tool'>
         <img src={img4}/>
         <div className='tool-info'>
         <span>follow scanner</span>
            
           <span>
           <span id='tool-span'>
          <br></br>
            <img src={img}/>
             <span>onfollow</span>
            <BsStarFill color="yellow"/>
            <i>593</i>
           </span>
           <br></br>
           <span><i>typescript</i>  <i>#Active</i>  <i>api</i>  <i>#Documentation </i></span>

           </span>
         </div>
        </div>
        <div className='inner-tool'>
         <img src={img4}/>
         <div className='tool-info'>
         <span>Overflow</span>
            
           <span>
           <span id='tool-span'>
          <br></br>
            <img src={img}/>
             <span>onfollow</span>
            <BsStarFill color="yellow"/>
            <i>123</i>
           </span>
           <br></br>
           <span><i>#Go</i>  <i>#testing</i>  <i>#cadence</i></span>
           </span>
         </div>
        </div>

      </div>
      </div>
      <div className='btnsqi'>
        <button id='btn111' type='button'>Submit button<i><BsArrowUpRight/></i></button>
        <button id='btn222' type='button'>View all button <i><IoIosArrowForward/></i></button>
      </div>

    </div>
  )
}
