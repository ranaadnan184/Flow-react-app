import React from 'react'
import './style.css';

import { GiGraduateCap} from 'react-icons/gi';
import { BsArrowUpRight} from 'react-icons/bs';
import { IoIosArrowForward} from 'react-icons/io';
import { MdForum} from 'react-icons/md';
import { SiTwitter} from 'react-icons/si';
import { SiDiscord} from 'react-icons/si';

import { AiOutlineGithub} from 'react-icons/ai';
export default function Morecontent() {
  return (
    <div>
      <div className='main-content-bg-pic'>
        <div className="">
            <div id='heading-content'>
            <h2 >Explore more content</h2>

            </div>
            <div className='parent-content-1'>
            <div className='inner-content-1'>
            <p id='cap'><GiGraduateCap size={50}/></p>

            <span>
            <h4>Learn</h4>
            <IoIosArrowForward/>
            </span>
            <p>All Resources you need to learn and build</p>
            </div>
            <div className='inner-content-1'>
            <p id='cap'><GiGraduateCap size={50}/></p>

            <span>

            <h4>tools</h4>
            <IoIosArrowForward/>
            </span>
            <p>Curated list of developer tools Services And SDks</p>
            </div>
            <div className='inner-content-1'>
            <p id='cap'><GiGraduateCap size={50}/></p>

            <span>

            <h4>Community </h4>
            <IoIosArrowForward/>
            </span>
            <p>Learn more about Flows Ecosystem and get involved</p>
            </div>
            </div>
            <div className='inner-second'>
            <div className='parent-content-2'>
            <div className='inner-content-2'>
            <p id='cap'><AiOutlineGithub size={50}/></p>
            <span id='span-set'>

            <h4>GitHub</h4>

            <span id='seticon'><p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio quisquam volu  </p><BsArrowUpRight/></span>

            </span>
            </div>
            <div className='inner-content-2'>
            <p id='cap'><MdForum size={50}/></p>
            <span id='span-set'>
            <h4>Forum</h4>

            
            <span id='seticon'><p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio quisquam volu  </p><BsArrowUpRight/></span>

            
            </span>
            </div>
            </div>
            <div className='parent-content-2'>
            <div className='inner-content-2'>
            <p id='cap'><SiDiscord size={50}/></p>
            <span id='span-set'>

            <h4>Discoverd</h4>

            <span id='seticon'><p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio quisquam volu  </p><BsArrowUpRight/></span>

            </span>
            </div>
            <div className='inner-content-2'>
            <p id='cap'><SiTwitter size={50}/></p>
            <span id='span-set'>
            <h4>Twitter</h4>

            
            <span id='seticon'><p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio quisquam volu  </p><BsArrowUpRight/></span>

            
            </span>
            </div>
            </div>
            </div>
        </div>
      </div>
    </div>
  )
}
